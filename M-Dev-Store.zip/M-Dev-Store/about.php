

<?php 

session_start();

include("includes/db.php");
include("functions/functions.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>M-Dev Store</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">

    <link rel="stylesheet" href="about.css">



</head>
<body>
   
   <div id="top"><!-- Top Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="col-md-6 offer"><!-- col-md-6 offer Begin -->
               
               <a href="#" class="btn btn-success btn-sm">
                   
                   <?php 
                   
                   if(!isset($_SESSION['customer_email'])){
                       
                       echo "Welcome: Guest";
                       
                   }else{
                       
                       echo "Welcome: " . $_SESSION['customer_email'] . "";
                       
                   }
                   
                   ?>
                   
               </a>
               <a href="checkout.php"><?php items(); ?> Items In Your Cart | Total Price: <?php total_price(); ?> </a>
               
           </div><!-- col-md-6 offer Finish -->
           
           <div class="col-md-6"><!-- col-md-6 Begin -->
               
               <ul class="menu"><!-- cmenu Begin -->
                   
               <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       <a href="customer_register.php">Register</a>
                   </li>
                   <li>
                       <a href="checkout.php">My Account</a>
                   </li>
                   <li>
                       <a href="cart.php">Cart</a>
                   </li>

                   <li>
                       <a href="shop.php">Shop</a>
                   </li>
                   <li>
                       <a href="contact.php">Contact Us</a>
                   </li>
                   <li>
                       <a href="about.php">About Us</a>
                   </li>

                   <li>
                       <a href="checkout.php">
                           
                           <?php 
                           
                           if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='checkout.php'> Login </a>";

                               }else{

                                echo " <a href='logout.php'> Log Out </a> ";

                               }
                           
                           ?>
                           
                       </a>
                   </li>
                   
               </ul><!-- menu Finish -->
               
           </div><!-- col-md-6 Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- Top Finish -->
   
  





   <body>

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
        <div class="container">
  
          <div class="section-title">
            <h2>About Us</h2>
            <p>Mobile Dev Media is an International e-commerce company, headquartered in Singapore, and incorporated in USA as a private limited company. The company initially focused on online mobile sales before expanding into other product categories such as consumer electronics, fashion, home essentials, groceries, and lifestyle products.
            </p>
          </div>
  
          <div class="row content">
            <div class="col-lg-6">
              <p>
             <strong>  Some of the content are not provided in websites so we recommend you to send us a message mentioning your  name.
            </strong> 
            </p>
 
              <ul>
                <li> This company was established by numbers of professionals for making the mobile phone easy access for everyone.</li>
            
              </ul>
              <br>
              <br>
              <a href="#" class="btn-learn-more">Send us a message</a>
            </div>
            



            <div class="col-lg-6 pt-4 pt-lg-0">


              <!-- user feedback -->
<section class="users-feedback">

  <h1 align="center">Member</h1>
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="user-review">
          <p>
              “Explore vast inventory & unique selection

Buyers who shop on the Mdev.com marketplace and its localized counterparts, as well as the  mobile phones, enjoy a highly personalized experience with an unparalleled selection at great value. ”
          </p><br>
          
          
          <h5>Sunil P.</h5>
          <small> Nepal</small>
        </div>
        <img src="https://i.ibb.co/FVyK1KM/user-2.png" alt="" />
      </div>

    </div>
  </div>
</section>

              
            </div>
          </div>
  
        </div>
      </section><!-- End About Us Section -->





   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>


